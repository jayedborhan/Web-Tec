<!DOCTYPE html>
<html lang="en">
    <head>
    </head>
    <body>
        <?php
        include ('../phpValidation/hi.php');
        ?>
        this is html
</body>