
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ExploreMate</title>
    
</head>

<style>
table, th, td {
  border:1px solid black;
}
</style>
<body>


    <header>
        <h1>ExploreMate</h1>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About US</a></li>
                <li><a href="#proile">Profile</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>



<center>

    <h2>Hotel book</h2>

    

        <table border="1" cellspacing="0" cellpadding="8">
       
         <tr>
      <th colspan="5"><h1> Available Hotel Room</h1></th>
	     </tr>
	    
            
                <tr>
                    <th>Room Number</th>
                    <th>Room Type</th>
                    <th>Capacity</th>
                    <th>Price per Night</th>
                    <th>Book Now</th>
                </tr>
            
            
                <tr>
                    <td>101</td>
                    <td>Standard</td>
                    <td>2 guests</td>
                    <td>1000/-</td>
                    <td><a href="hotelpayment.php">Reserve</a></td>
                </tr>
                <tr>
                    <td>202</td>
                    <td>Deluxe</td>
                    <td>3 guests</td>
                    <td>1500/-</td>
                    <td><a href="hotelpayment.php">Reserve</a></td>
                </tr>
                <tr>
                    <td>303</td>
                    <td>Suite</td>
                    <td>4 guests</td>
                    <td>3000/-</td>
                    <td><a href="hotelpayment.php">Reserve</a></td>
                </tr>
                
            
        </table>

   

    <a href="AvailableHotel.php"><h4>Back</h4></a>



    <footer>
        <p> &copy; ExploreMate A Complete Tour Guide. All rights reserved.</p>
    </footer>
    
</body>
</html>
